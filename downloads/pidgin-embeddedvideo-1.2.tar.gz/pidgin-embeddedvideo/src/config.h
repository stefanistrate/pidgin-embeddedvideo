#define PLUGIN_ID "gtk-stef2n_mariusl-embeddedvideo"
